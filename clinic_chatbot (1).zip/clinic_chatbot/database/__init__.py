"""Database package (SQLite)."""
